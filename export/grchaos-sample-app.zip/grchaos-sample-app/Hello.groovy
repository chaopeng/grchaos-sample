/**
 * .Hello
 *
 * @author chao
 * @version 1.0 - 2016-07-05
 */
class Hello {
}
